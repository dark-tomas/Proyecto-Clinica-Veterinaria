package conex;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class consultas {
    
    public boolean autenticacion(String usuario, String clave) {
        conexion con = new conexion();
        Connection conexion = con.obtenerConexion();

        try {
            String consulta = "SELECT * FROM Usuarios WHERE username = ? AND password = ?";
            PreparedStatement pst = conexion.prepareStatement(consulta);
            pst.setString(1, usuario);
            pst.setString(2, clave);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return true;  // Credenciales válidas
            } else {
                return false; // Credenciales inválidas
            }

        } catch (SQLException e) {
            System.out.println("Error al autenticar: " + e);
            return false;
        }
    }
    
    
    public boolean registrarUsuario(String usuario, String contraseña, Connection conexion) {
        try {
            String query = "INSERT INTO Usuarios (id_usuarios, username, password) VALUES (?, ?, ?)";
            PreparedStatement pst = conexion.prepareStatement(query);
            pst.setString(1, null); // Aquí deberías pasar el valor correcto para el campo id_usuarios, o ajustar la consulta SQL.
            pst.setString(2, usuario);
            pst.setString(3, contraseña);

            int resultado = pst.executeUpdate();

            return resultado > 0;
        } catch (SQLException e) {
            System.out.println("Error al registrar usuario: " + e);
            return false;
        } finally {
            try {
                if (conexion != null) {
                    conexion.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e);
            }
        }
    }
    
    
    
    
    
    
    
    
    
}