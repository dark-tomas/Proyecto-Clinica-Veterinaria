package interfaces;

import conex.conexion;
import conex.consultas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class registro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					registro frame = new registro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public registro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 540, 718);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 524, 679);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblRegistro = new JLabel("Registro");
		lblRegistro.setForeground(new Color(64, 128, 128));
		lblRegistro.setBackground(new Color(255, 255, 255));
		lblRegistro.setFont(new Font("Lucida Sans", Font.PLAIN, 40));
		lblRegistro.setBounds(158, 11, 184, 48);
		panel.add(lblRegistro);
		
		JLabel lblUsuario = new JLabel("Usuario:");
		lblUsuario.setForeground(new Color(64, 128, 128));
		lblUsuario.setFont(new Font("Dialog", Font.BOLD, 26));
		lblUsuario.setBackground(Color.WHITE);
		lblUsuario.setBounds(90, 413, 139, 48);
		panel.add(lblUsuario);
		
		JLabel lblContraseña = new JLabel("Contraseña:");
		lblContraseña.setForeground(new Color(64, 128, 128));
		lblContraseña.setFont(new Font("Dialog", Font.BOLD, 26));
		lblContraseña.setBackground(Color.WHITE);
		lblContraseña.setBounds(49, 472, 180, 46);
		panel.add(lblContraseña);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setForeground(Color.BLACK);
		textField.setFont(new Font("Lucida Sans", Font.PLAIN, 18));
		textField.setColumns(10);
		textField.setBackground(Color.LIGHT_GRAY);
		textField.setBounds(234, 416, 242, 37);
		panel.add(textField);
		
		passwordField = new JPasswordField();
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setForeground(Color.BLACK);
		passwordField.setBackground(Color.LIGHT_GRAY);
		passwordField.setBounds(234, 481, 242, 37);
		panel.add(passwordField);
		
		JButton btnNewButton = new JButton("  Regresar");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton.setIcon(new ImageIcon(registro.class.getResource("/imagenes/atras.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Al hacer clic en el botón Regresar, abre el JFrame de login y cierra el JFrame de registro
                login frameLogin = new login();
                frameLogin.setVisible(true);
                dispose(); // Cierra el JFrame actual (registro)
			}
		});
		btnNewButton.setBounds(33, 577, 172, 58);
		panel.add(btnNewButton);
		
		JButton btnRegistrar = new JButton("     Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Obtiene las credenciales ingresadas por el usuario
                String usuario = textField.getText();
                String contraseña = new String(passwordField.getPassword());

                // Crea una instancia de la clase Conexion
                conexion conexionBD = new conexion();

                // Obtiene la conexión
                Connection conexion = conexionBD.obtenerConexion();

                // Registra al usuario en la base de datos
                consultas consultasBD = new consultas();
                if (consultasBD.registrarUsuario(usuario, contraseña, conexion)) {
                    // Registro exitoso, puedes mostrar un mensaje o realizar otras acciones si es necesario
                    JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente");
                } else {
                    // Error en el registro
                    JOptionPane.showMessageDialog(null, "Error al registrar usuario");
                }

                // Cierra la conexión
                try {
                    if (conexion != null) {
                        conexion.close();
                    }
                } catch (SQLException ex) {
                    System.out.println("Error al cerrar la conexión: " + ex);
                }
				
				
			}
		});
		btnRegistrar.setIcon(new ImageIcon(registro.class.getResource("/imagenes/user-add.png")));
		btnRegistrar.setHorizontalAlignment(SwingConstants.LEFT);
		btnRegistrar.setForeground(Color.BLACK);
		btnRegistrar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnRegistrar.setBackground(Color.WHITE);
		btnRegistrar.setBounds(272, 577, 203, 58);
		panel.add(btnRegistrar);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(registro.class.getResource("/imagenes/agregar-usuario.png")));
		lblNewLabel.setBounds(129, 70, 347, 332);
		panel.add(lblNewLabel);
	}
}
